<?php

    echo "ACEPTO Y LAS CONDICIONES";

?>